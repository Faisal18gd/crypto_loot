Last Updated: January 15, 2020

NO PURCHASE OR PAYMENT OF ANY KIND IS NECESSARY TO ENTER OR WIN ANY GAME.

A PURCHASE DOES NOT INCREASE YOUR CHANCES OF WINNING. VOID WHERE PROHIBITED. SOME GAMES REQUIRE TOKENS TO ENTER. TOKENS ARE PROVIDED FREE OF CHARGE.

THE APP, THE GAMES, AND ANY SWEEPSTAKES CONTAINED HEREIN ARE NOT SPONSORED BY, ENDORSED OR AFFILIATED IN ANY WAY WITH APPLE, INC.

Welcome to the Lucky Duel App. Lucky Duel, Inc. and/or its affiliates (“Lucky Duel, Inc.”) provide online and mobile gaming services to authorized users (“Company Services”) subject to the following terms and conditions contained herein, including all Official Rules of the Games played by you (the “Terms”).

By using the Lucky Duel App, you agree to these Terms. Please read them carefully.

For our Full Terms and Privacy Policy please visit luckyduel.com